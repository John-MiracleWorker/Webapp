"use client";

import { useState, useEffect, useRef } from "react";
import Fuse from 'fuse.js'; // Import Fuse.js
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Search, MessageSquare, Loader2, AlertCircle } from "lucide-react";
import protocolsData from "@/lib/protocols.json";

interface Protocol {
  name: string;
  content: string;
  source_file: string;
  id: string;
}

interface ProtocolData {
  [key: string]: Omit<Protocol, 'id'>;
}

interface ChatMessage {
    role: "user" | "bot" | "error";
    content: string;
}

const protocolsList: Protocol[] = Object.entries(protocolsData as ProtocolData).map(([key, protocol]) => ({
    ...protocol,
    id: key,
}));

// Fuse.js options for fuzzy search
const fuseOptions = {
  includeScore: true,
  threshold: 0.4, // Adjust threshold for sensitivity (0.0 = exact match, 1.0 = match anything)
  keys: [
    { name: 'name', weight: 0.6 }, // Higher weight for protocol name
    { name: 'id', weight: 0.5 },   // Medium weight for protocol ID
    { name: 'content', weight: 0.2 } // Lower weight for content
  ]
};

const fuse = new Fuse(protocolsList, fuseOptions);

export default function Home() {
  const [searchTerm, setSearchTerm] = useState("");
  const [searchResults, setSearchResults] = useState<Protocol[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [isChatMode, setIsChatMode] = useState(false);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [chatInput, setChatInput] = useState("");
  const [isChatLoading, setIsChatLoading] = useState(false);
  const chatContainerRef = useRef<HTMLDivElement>(null);

  // Fuzzy Search Functionality using Fuse.js
  const handleSearch = () => {
    if (!searchTerm.trim()) {
      setSearchResults([]);
      return;
    }
    setIsSearching(true);
    console.log(`Performing fuzzy search for: ${searchTerm}`);
    const results = fuse.search(searchTerm);
    const filteredResults = results.map(result => result.item); // Extract the protocol items
    console.log(`Found ${filteredResults.length} results with Fuse.js`);
    setSearchResults(filteredResults);
    setIsSearching(false);
    setIsChatMode(false); // Switch back to search results view
  };

  const handleInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(event.target.value);
  };

  const handleKeyDown = (event: React.KeyboardEvent<HTMLInputElement>) => {
    if (event.key === "Enter") {
      handleSearch();
    }
  };

  // Chat Functionality calling the backend API
  const handleChatSend = async () => {
    if (!chatInput.trim()) return;

    const userMessage: ChatMessage = { role: "user", content: chatInput };
    const currentMessages = [...chatMessages, userMessage];
    setChatMessages(currentMessages);
    setChatInput("");
    setIsChatLoading(true);

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ messages: currentMessages.slice(-6) }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ error: `API error: ${response.statusText}` }));
        throw new Error(errorData.error || `API error: ${response.statusText}`);
      }

      const data = await response.json();
      const botMessage: ChatMessage = { role: "bot", content: data.response };
      setChatMessages((prev) => [...prev, botMessage]);

    } catch (error) {
      console.error("Chat API error:", error);
      const errorMessage: ChatMessage = {
          role: "error",
          content: `Sorry, I encountered an error trying to respond. Please try again. (${error instanceof Error ? error.message : String(error)})`
      };
      setChatMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsChatLoading(false);
    }
  };

   const handleChatKeyDown = (event: React.KeyboardEvent<HTMLInputElement>) => {
    if (event.key === "Enter" && !isChatLoading) {
      handleChatSend();
    }
  };

  // Scroll chat to bottom
  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [chatMessages]);

  return (
    <div className="flex flex-col items-center min-h-screen bg-gray-50 p-4 md:p-8">
      <Card className="w-full max-w-4xl shadow-lg">
        <CardHeader className="text-center">
            <CardTitle className="text-3xl md:text-4xl font-bold text-gray-800">Oakland County EMS Protocols</CardTitle>
            <CardDescription>Search or chat to find protocol information</CardDescription>
        </CardHeader>
        <CardContent>
            {/* Search Bar */}
            <div className="w-full flex items-center space-x-2 mb-6">
                <Input
                type="text"
                placeholder="Search protocols (e.g., cardiac arrest adult)..."
                value={searchTerm}
                onChange={handleInputChange}
                onKeyDown={handleKeyDown}
                className="flex-grow"
                />
                <Button onClick={handleSearch} disabled={isSearching}>
                {isSearching ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />} <span className="ml-2 hidden sm:inline">Search</span>
                </Button>
                <Button variant="outline" onClick={() => setIsChatMode(!isChatMode)} title={isChatMode ? "Switch to Search" : "Switch to Chat"}>
                {isChatMode ? <Search className="h-4 w-4" /> : <MessageSquare className="h-4 w-4" />} <span className="ml-2 hidden sm:inline">{isChatMode ? "Search" : "Chat"}</span>
                </Button>
            </div>

            {/* Content Area: Search Results or Chat */}
            <div className="w-full h-[65vh] flex flex-col">
                {isChatMode ? (
                // Chat Interface
                <div className="h-full flex flex-col border rounded-md">
                    <ScrollArea className="flex-grow p-4" ref={chatContainerRef}>
                        {chatMessages.map((msg, index) => (
                        <div key={index} className={`mb-3 flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
                            <div className={`p-3 rounded-lg max-w-[80%] ${msg.role === "user" ? "bg-blue-500 text-white" : msg.role === "bot" ? "bg-gray-200 text-gray-800" : "bg-red-100 text-red-700"}`}>
                                {msg.role === "error" && <AlertCircle className="inline-block h-4 w-4 mr-1 mb-0.5"/>}
                                <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                            </div>
                        </div>
                        ))}
                        {isChatLoading && (
                            <div className="flex justify-start mb-3">
                                <div className="bg-gray-200 p-3 rounded-lg inline-flex items-center">
                                    <Loader2 className="h-4 w-4 animate-spin mr-2" /> Thinking...
                                </div>
                            </div>
                        )}
                    </ScrollArea>
                    <div className="flex items-center space-x-2 p-4 border-t bg-gray-50 rounded-b-md">
                        <Input
                        placeholder="Type your question..."
                        value={chatInput}
                        onChange={(e) => setChatInput(e.target.value)}
                        onKeyDown={handleChatKeyDown}
                        disabled={isChatLoading}
                        className="flex-grow text-black" // Explicitly set text color to black
                        />
                        <Button onClick={handleChatSend} disabled={isChatLoading || !chatInput.trim()}>
                        {isChatLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : "Send"}
                        </Button>
                    </div>
                </div>
                ) : (
                // Search Results
                <ScrollArea className="h-full border rounded-md p-4">
                    {searchResults.length > 0 ? (
                    <div className="space-y-4">
                        {searchResults.map((protocol, index) => {
                            // console.log(`Rendering protocol ${protocol.id}: ${protocol.name}, Content length: ${protocol.content?.length}`); // Log content length
                            return (
                                <Card key={protocol.id}>
                                    <CardHeader>
                                    <CardTitle>{protocol.name} ({protocol.id})</CardTitle>
                                    <CardDescription>Source: {protocol.source_file}</CardDescription>
                                    </CardHeader>
                                    <CardContent>
                                    {/* Explicitly style pre tag for visibility */}
                                    <pre className="whitespace-pre-wrap text-sm font-sans bg-gray-100 text-gray-900 p-3 rounded overflow-x-auto border border-gray-300 min-h-[50px]">{protocol.content || "Content not available."}</pre>
                                    </CardContent>
                                </Card>
                            );
                        })}
                    </div>
                    ) : (
                    <div className="text-center text-gray-500 pt-10">
                        {searchTerm ? "No protocols found matching your search." : "Enter a search term above or switch to chat mode."}
                    </div>
                    )}
                </ScrollArea>
                )}
            </div>
        </CardContent>
      </Card>
    </div>
  );
}

