import { OpenAI } from "openai";
import { NextRequest, NextResponse } from "next/server";
import protocolsData from "@/lib/protocols.json";

interface Protocol {
  name: string;
  content: string;
  source_file: string;
}

interface ProtocolData {
  [key: string]: Protocol;
}

const protocols: ProtocolData = protocolsData;

const openaiApiKey = "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";

if (!openaiApiKey) {
  console.error("OpenAI API key is missing!");
}

let openai: OpenAI;
try {
  openai = new OpenAI({
      apiKey: openaiApiKey,
  });
  console.log("OpenAI client initialized successfully.");
} catch (initError) {
  console.error("Failed to initialize OpenAI client:", initError);
}

// Function to find relevant protocols (scoring based on keyword matches)
function findRelevantProtocols(query: string): Protocol[] {
    const lowerCaseQuery = query.toLowerCase();
    // Split query into keywords, remove common short words/stop words
    const queryKeywords = lowerCaseQuery.split(/\s+/).filter(kw => kw.length > 2 && !["is", "the", "for", "and", "a", "of", "to", "in"].includes(kw));

    if (queryKeywords.length === 0) {
        return []; // No meaningful keywords
    }

    const scoredProtocols = Object.values(protocols).map((protocol) => {
        const protocolNameLower = protocol.name.toLowerCase();
        const protocolContentLower = protocol.content.toLowerCase();
        let score = 0;

        queryKeywords.forEach(kw => {
            if (protocolNameLower.includes(kw)) {
                score += 2; // Higher weight for name match
            }
            if (protocolContentLower.includes(kw)) {
                score += 1; // Lower weight for content match
            }
        });

        // Bonus for matching multiple keywords
        const nameMatchCount = queryKeywords.filter(kw => protocolNameLower.includes(kw)).length;
        const contentMatchCount = queryKeywords.filter(kw => protocolContentLower.includes(kw)).length;
        if (nameMatchCount > 1) score += nameMatchCount * 2;
        if (contentMatchCount > 1) score += contentMatchCount;

        return { protocol, score };
    });

    // Filter out protocols with zero score and sort by score descending
    const sortedResults = scoredProtocols
        .filter(item => item.score > 0)
        .sort((a, b) => b.score - a.score);

    // Limit the number of protocols sent to GPT
    return sortedResults.slice(0, 5).map(item => item.protocol); // Return top 5 protocols
}

export async function POST(request: NextRequest) {
  console.log("Received POST request to /api/chat (Node.js runtime)");
  if (!openai) {
    console.error("OpenAI client is not initialized.");
    return NextResponse.json({ error: "AI service initialization failed" }, { status: 500 });
  }

  try {
    const { messages } = await request.json();
    console.log("Parsed messages:", JSON.stringify(messages));

    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      console.error("Invalid request body received");
      return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
    }

    const userQuery = messages[messages.length - 1]?.content;
    if (!userQuery) {
        console.error("No user query found in messages");
        return NextResponse.json({ error: "No user query found" }, { status: 400 });
    }
    console.log("User query:", userQuery);

    const relevantProtocols = findRelevantProtocols(userQuery);
    console.log(`Found ${relevantProtocols.length} relevant protocols with scoring search.`);
    relevantProtocols.forEach((p, index) => console.log(`  ${index + 1}. ${p.name} (Source: ${p.source_file})`)); // Log found protocols

    const protocolContext = relevantProtocols.map(p => `Protocol ${p.name} (Source: ${p.source_file}):\n${p.content}`).join("\n\n---\n\n");

    const systemPrompt = `You are an AI assistant specialized in the Oakland County EMS protocols. Your knowledge base consists ONLY of the following protocols provided below. Answer the user's questions based *strictly* on this information. If the answer cannot be found in the provided protocols, state that clearly. Do not invent information or use external knowledge. Be concise and helpful.

Relevant Protocols:
${protocolContext || "No specific protocols found matching the query."}`;

    const apiMessages = [
        { role: "system", content: systemPrompt },
        ...messages.slice(-5), // Send last 5 messages
      ];
    // console.log("Messages being sent to OpenAI:", JSON.stringify(apiMessages)); // Can be verbose

    console.log("Sending request to OpenAI chat completion...");
    const chatCompletion = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: apiMessages,
      temperature: 0.5,
      max_tokens: 1000,
    });
    console.log("Received response from OpenAI.");

    const botResponse = chatCompletion.choices[0]?.message?.content;

    if (!botResponse) {
        console.error("Failed to get valid response content from OpenAI. Full response:", JSON.stringify(chatCompletion));
        return NextResponse.json({ error: "Failed to get response from AI" }, { status: 500 });
    }

    console.log("Sending bot response to client:");
    return NextResponse.json({ response: botResponse });

  } catch (error) {
    console.error("Detailed Error processing chat request:", error);
    let errorMessage = "Internal Server Error";
    if (error instanceof Error) {
        errorMessage = error.message;
        if (error.name === 'AuthenticationError') {
             errorMessage = "OpenAI Authentication Error. Please check the API key.";
        } else if (error.name === 'APIConnectionError') {
             errorMessage = "Could not connect to OpenAI API. Please check network.";
        } else if (error.name === 'RateLimitError') {
             errorMessage = "OpenAI API rate limit exceeded. Please try again later.";
        }
    }
    console.error("Error Details:", errorMessage);
    return NextResponse.json({ error: errorMessage }, { status: 500 });
  }
}

